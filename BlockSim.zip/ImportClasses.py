from InputsConfig import InputsConfig as p

'''
class Block:

     if p.model ==0 or p.model==1:
        from Models.Block import Block as Block
     elif p.model ==2:
        from Models.Ethereum.Block import Block as Block



class Transaction:
     from InputsConfig import InputsConfig as p
     if p.model ==0 or p.model==1:
        from Models.Transaction import LightTransaction as LT, FullTransaction as FT
     elif p.model ==2:
        from Models.Ethereum.Transaction import LightTransaction as LT, FullTransaction as FT

#class Node:
#     from InputsConfig import InputsConfig as p
#     if p.model ==0 or p.model==1:
##        from Models.Bitcoin.Node import Node as Node
#     elif p.model ==2:
#        from Models.Ethereum.Node import Node as Node

class Consensus:
     from InputsConfig import InputsConfig as p
     if p.model ==0 or p.model==1:
        from Models.Consensus import Consensus
     elif p.model ==2:
        from Models.Ethereum.Consensus import Consensus

class BlockCommit:
     from InputsConfig import InputsConfig as p
     if p.model ==0 or p.model==1:
        from Models.Bitcoin.BlockCommit import BlockCommit
     elif p.model ==2:
        from Models.Ethereum.BlockCommit import BlockCommit


if p.model ==0:
	from Models.Block import Block as Block
	from Models.Transaction import LightTransaction as LT, FullTransaction as FT
	model= __import__(Models)


elif p.model ==1:
        from Models.Bitcoin.BlockCommit import BlockCommit
        from Models.Bitcoin.Consensus import Consensus
        from Models.Bitcoin.Node import Node
        model= __import__(Models.Bitcoin)

elif p.model ==2:
	#from Models.Ethereum.Block import Block as Block
	#from Models.Ethereum.Transaction import LightTransaction as LT, FullTransaction as FT
	#from Models.Ethereum.BlockCommit import BlockCommit
	#from Models.Ethereum.Consensus import Consensus
	#from Models.Ethereum.Node import Node as Node
        model= 'Models.Ethereum'

'''

if p.model==2:
	from Models.Ethereum.BlockCommit import BlockCommit
	from Models.Ethereum.Consensus import Consensus
	from Models.Ethereum.Transaction import LightTransaction as LT, FullTransaction as FT
	from Models.Ethereum.Node import Node
	from Models.Ethereum.Incentives import Incentives

elif p.model==1:
	from Models.Bitcoin.BlockCommit import BlockCommit
	from Models.Bitcoin.Consensus import Consensus
	from Models.Transaction import LightTransaction as LT, FullTransaction as FT
	from Models.Bitcoin.Node import Node
	from Models.Incentives import Incentives

elif p.model==0:
	from Models.BlockCommit import BlockCommit
	from Models.Consensus import Consensus
	from Models.Transaction import LightTransaction as LT, FullTransaction as FT
	from Models.Node import Node
	from Models.Incentives import Incentives
